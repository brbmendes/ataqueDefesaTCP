gcc -o bin/attack sources/functions.c sources/attack.c headers/functions.h
gcc -o bin/stealth_scan_fin sources/stealth_scan_fin.c
gcc -o bin/syn_ack sources/syn_ack.c
gcc -o bin/tcp_connect sources/tcp_connect.c
gcc -o bin/tcp_half_opening sources/tcp_half_opening.c
gcc -o bin/sniffer sources/sniffer.c
